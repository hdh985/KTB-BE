package com.yagsog.api.user;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Transactional
public class UserController {
    private UserService userService;

    @PostMapping("/api/name")
    public ResponseEntity<User> updateName(@RequestBody String name) {
//        userService.updateUserInfo();
//        return ResponseEntity.ok()

    }

    @PostMapping("/api/age")
    public ResponseEntity<User> updateAge(@RequestBody String name) {

    }

    @PostMapping("/api/gender")
    public ResponseEntity<User> updateGender(@RequestBody String name) {

    }

    @PostMapping("/api/medications")
    public ResponseEntity<User> updateMedications(@RequestBody String name) {

    }


}
